import java.net.*;
import java.io.*;
import java.util.*;
import javax.crypto.SecretKey;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.KeyFactory;
import java.security.spec.PKCS8EncodedKeySpec;

public class Client {
	final static Scanner scan = new Scanner(System.in);
    public static void main(String[] args) throws Exception{
    final String AES_KEY_FILE = "AES.key", DECRYPTED_FILE = "decrypted.txt", ENCRYPTED_FILE = "encrypted.txt", GENERATED_MAC = "generated.mac", RSA_KEY_FILE = "RSA.der", SERVER_MAC = "server.mac";
        try {
            Socket socket = new Socket("localhost", 9999);
            System.out.println("Connection established with server");

            // Send file to server
            
            //Establishing Output/Input 
            OutputStream outputStream = socket.getOutputStream();
            DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
            InputStream inputStream = socket.getInputStream();
            DataInputStream dataInputStream = new DataInputStream(inputStream);
            RSAEncryptionProgram RSA = new RSAEncryptionProgram();
            AESEncryptionExample AES = new AESEncryptionExample();
            
            //Generate AES Key
            SecretKey local_AES = AES.generateAESKey();
            AES.saveSecretKey(local_AES, AES_KEY_FILE);
            
            //Get public key from server
            String fileName = dataInputStream.readUTF();
            long fileSize = dataInputStream.readLong();         
            //Reading the inputStream from Server
            FileOutputStream fileOutputStream = new FileOutputStream(RSA_KEY_FILE);
            byte[] buffer = new byte[4096];
            int read = 0;
            int totalRead = 0;
            int remaining = (int) fileSize;
            while ((read = inputStream.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
                totalRead += read;
                remaining -= read;
                fileOutputStream.write(buffer, 0, read);
            }
            
            System.out.println("File " + fileName + " received successfully");
           
            System.out.println("Encrypting Key");

            //Sending AES key file encrypted with RSA
                        
            RSA.encryptFile(AES_KEY_FILE, RSA_KEY_FILE, ENCRYPTED_FILE);
            fileName = ENCRYPTED_FILE;

	    File localPublicFile = new File(ENCRYPTED_FILE);
	    fileSize = localPublicFile.length();

	    dataOutputStream.writeUTF(ENCRYPTED_FILE);
	    dataOutputStream.writeLong(fileSize);
            System.out.println("Sending file " + ENCRYPTED_FILE + " (" + fileSize + " bytes)");
            FileInputStream fileInputStream = new FileInputStream(localPublicFile);
            buffer = new byte[4096];
            read = 0;
            totalRead = 0;
            remaining = (int) fileSize;
            while ((read = fileInputStream.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
                totalRead += read;
                remaining -= read;
                outputStream.write(buffer, 0, read);
            }

            System.out.println("File " + fileName + " sent successfully");
            
            //Send file with AES encryption now.

            fileName = scan.nextLine();
            
	    AES.generateMAC(local_AES, fileName, GENERATED_MAC); //generating MAC to send
            AES.encryptFile(fileName, ENCRYPTED_FILE, local_AES); //encrypted file 
            
            fileName = ENCRYPTED_FILE;
            
            localPublicFile = new File(ENCRYPTED_FILE); //encrypted file = localPublicFile
	    fileSize = localPublicFile.length();
            
            fileInputStream = new FileInputStream(localPublicFile); //fileInputStream = encrypted file
            buffer = new byte[4096];
            read = 0;
            totalRead = 0;
            remaining = (int) fileSize;
            dataOutputStream.writeUTF(ENCRYPTED_FILE);
            dataOutputStream.writeLong(fileSize);
            while ((read = fileInputStream.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
                totalRead += read;
                remaining -= read;
                outputStream.write(buffer, 0, read); //writes encrypted to socket
            }
            
            //Send signature over to server
            
            //fileName = GENERATED_MAC   working with MAC
            
            localPublicFile = new File(GENERATED_MAC); //MAC = localPublicFile
	    fileSize = localPublicFile.length();
            
            fileInputStream = new FileInputStream(localPublicFile); //fileInputStream = encrypted file
            buffer = new byte[4096];
            read = 0;
            totalRead = 0;
            remaining = (int) fileSize;
            dataOutputStream.writeUTF(GENERATED_MAC);
            dataOutputStream.writeLong(fileSize);
            while ((read = fileInputStream.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
                totalRead += read;
                remaining -= read;
                outputStream.write(buffer, 0, read); //writes encrypted to socket
            }
            
            //Receive acknoweldgement 
            fileName = dataInputStream.readUTF();
            fileSize = dataInputStream.readLong();
            fileOutputStream = new FileOutputStream(fileName);
            buffer = new byte[4096];
            read = 0;
            totalRead = 0;
            remaining = (int) fileSize;
            while ((read = inputStream.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
                totalRead += read;
                remaining -= read;
                fileOutputStream.write(buffer, 0, read);
            }
            
            System.out.println("File " + fileName + " received successfully");
	    System.out.println("Decrypting " + fileName);
	    
	    AES.decryptFile(fileName, DECRYPTED_FILE, local_AES);
            
            System.out.println("Receiving MAC");

            //Receiving MAC file
            fileName = dataInputStream.readUTF();
            fileSize = dataInputStream.readLong();
            fileOutputStream = new FileOutputStream(fileName);
            buffer = new byte[4096];
            read = 0;
            totalRead = 0;
            remaining = (int) fileSize;
            while ((read = inputStream.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
                totalRead += read;
                remaining -= read;
                fileOutputStream.write(buffer, 0, read);
            }
            
	    File signatureFile = new File(fileName);
	    File decryptedFile = new File(DECRYPTED_FILE);
	    
	    AES.generateMAC(local_AES, DECRYPTED_FILE, GENERATED_MAC);
	    
            if(AES.verifyMAC(fileName, GENERATED_MAC))
	    {
            	System.out.println("File " + fileName + " received successfully");
            }
            else
            {
            	System.out.println("File not verified!");
            	File tempFile = new File(DECRYPTED_FILE);
            	tempFile.delete();
            }
            
            //Cleanup
	    File tempFile = new File(AES_KEY_FILE);
	    tempFile.delete();
	    tempFile = new File(RSA_KEY_FILE);
	    tempFile.delete();
	    tempFile = new File(ENCRYPTED_FILE);
	    tempFile.delete();
	    tempFile = new File(GENERATED_MAC);
	    tempFile.delete();
	    tempFile = new File(SERVER_MAC);
	    tempFile.delete();
	    

            fileOutputStream.close();
            dataInputStream.close();
            inputStream.close();
            dataOutputStream.close();
	    socket.close();
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
        
    }
}
