import java.net.*;
import java.io.*;
import java.util.Arrays;
import java.util.Scanner;
import java.lang.Object;
import java.nio.file.*;
import javax.crypto.SecretKey;


public class Server {
    public static void main(String[] args) throws Exception{
    	final String AES_KEY_FILE = "AES.key", INCOMING_FILE = "temp.file", CLIENT_MAC = "client.mac", GENERATED_MAC = "generated.mac", PUBLIC_RSA = "public.der", PRIVATE_RSA = "private.der", ENCRYPTED_FILE = "encrypted.txt", DECRYPTED_FILE = "decrypted.txt";
	//Initiate File Receive
	File terminationFile = new File("Shutdown");
	boolean active = true;
	do{
        try {
            //Server listening on port 9999
            ServerSocket serverSocket = new ServerSocket(9999);
            System.out.println("Server listening on port 9999");
            Socket clientSocket = serverSocket.accept();
            System.out.println("Connection established with " + clientSocket.getInetAddress().getHostName());

	    //Server talking on port 9998 to Client
	    //DONT DO THIS, USE INPUTSTREAM ON CLIENT SIDE FOR OUTPUTS
	    //Socket socket = new Socket("localhost", 9998);
            //System.out.println("Connection established with Client");
            
            //Enabling sending data over the socket
            OutputStream outputStream = clientSocket.getOutputStream();
            DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
            InputStream inputStream = clientSocket.getInputStream();
            DataInputStream dataInputStream = new DataInputStream(inputStream);
            RSAEncryptionProgram RSA = new RSAEncryptionProgram();
            AESEncryptionExample AES = new AESEncryptionExample();
            
            RSA.generateKeys();


	    //Sending public key RSA to client
	    String fileName = "public.der";

	    File localPublicKeyFile = new File(fileName);
	    long fileSize = localPublicKeyFile.length();
	    
	    //First server output is sending file name/size
	    dataOutputStream.writeUTF("ServerPublic.der");
	    dataOutputStream.writeLong(fileSize);
            System.out.println("Sending file " + fileName + " (" + fileSize + " bytes)");
            
            //Send public key
            
            FileInputStream fileInputStream = new FileInputStream(localPublicKeyFile);
            byte[] buffer = new byte[4096];
            int read = 0;
            int totalRead = 0;
            int remaining = (int) fileSize;       
            while ((read = fileInputStream.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
                totalRead += read;
                remaining -= read;
                outputStream.write(buffer, 0, read);
            }

            System.out.println("File " + fileName + " sent successfully");
            
            
            //AES key from Client - Encrypted
            System.out.println("Receiving AES Key");
         
            fileName = dataInputStream.readUTF(); 
            fileSize = dataInputStream.readLong();
            FileOutputStream fileOutputStream = new FileOutputStream(ENCRYPTED_FILE);
            buffer = new byte[4096];
            read = 0;
            totalRead = 0;
            remaining = (int) fileSize;
            while ((read = inputStream.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
                totalRead += read;
                remaining -= read;
                fileOutputStream.write(buffer, 0, read);
            }
            
            System.out.println("File " + fileName + " received successfully");
            
            System.out.println("Decrypting AES Key");
            //Gather AES Key
            RSA.decryptFile(ENCRYPTED_FILE, AES_KEY_FILE);  
            SecretKey AES_KEY = AES.loadSecretKey(AES_KEY_FILE);
            
            System.out.println("Receiving file");

            //Receiving encrypted file
            fileName = dataInputStream.readUTF(); //filename = whatever came in
            fileSize = dataInputStream.readLong();
            fileOutputStream = new FileOutputStream(ENCRYPTED_FILE); //file path = filename
            buffer = new byte[4096];
            read = 0;
            totalRead = 0;
            remaining = (int) fileSize;
            while ((read = inputStream.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
                totalRead += read;
                remaining -= read;
                fileOutputStream.write(buffer, 0, read);
            }
            System.out.println("File " + fileName + " received successfully");
            
            System.out.println("Decrypting " + fileName);

	    AES.decryptFile(ENCRYPTED_FILE, DECRYPTED_FILE, AES_KEY);
            AES.generateMAC(AES_KEY, DECRYPTED_FILE, GENERATED_MAC); //THIS IS WRONG SOMEHOW
            
            System.out.println("Receiving MAC");
            
            
            //Receiving plain mac file
            fileName = dataInputStream.readUTF();
            fileSize = dataInputStream.readLong();
            fileOutputStream = new FileOutputStream(CLIENT_MAC);
            buffer = new byte[4096];
            read = 0;
            totalRead = 0;
            remaining = (int) fileSize;
            while ((read = inputStream.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
                totalRead += read;
                remaining -= read;
                fileOutputStream.write(buffer, 0, read);
            }
            System.out.println("File " + fileName + " received successfully");

	    System.out.println("Verifying file");
	    //File signatureFile = new File(fileName);
	    File decryptedFile = new File(DECRYPTED_FILE);
	    

	    
	    if(AES.verifyMAC(CLIENT_MAC,GENERATED_MAC))//
	    {
	    	System.out.println("File verified!");
	    	//signatureFile.delete();
	    	if(Arrays.equals(Files.readAllBytes(terminationFile.toPath()),Files.readAllBytes(decryptedFile.toPath())))
            	{
            		System.out.println("Shutdown commensed");
            		active = false;
            	}
	    	else{
	    		System.out.print("File contents: \"");
	    		Scanner myReader = new Scanner(decryptedFile);
	    		while(myReader.hasNextLine())
	    			System.out.println(myReader.nextLine());
	    		System.out.print("\"");
	    	}
	    	System.out.println("");
	    	
	    	
	    	fileName = "ServerResponse.txt"; //generateMAC input file
	    	
	    	AES.generateMAC(AES_KEY, fileName, GENERATED_MAC);
	    	AES.encryptFile(fileName, ENCRYPTED_FILE, AES_KEY); //encrypted file into local file
            
            	File localPublicFile = new File(ENCRYPTED_FILE);
	    	fileSize = localPublicFile.length();
            
            	fileInputStream = new FileInputStream(localPublicFile);
            	buffer = new byte[4096];
            	read = 0;
            	totalRead = 0;
            	remaining = (int) fileSize;
            	
            	

            
            	//Encrypted file send to client
            	dataOutputStream.writeUTF(ENCRYPTED_FILE);
            	dataOutputStream.writeLong(fileSize);
            	while ((read = fileInputStream.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
                	totalRead += read;
                	remaining -= read;
                	outputStream.write(buffer, 0, read);
            	}
            
            //Send file with buffer
            
            	while ((read = fileInputStream.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
                	totalRead += read;
                	remaining -= read;
                	outputStream.write(buffer, 0, read);
            	}

            	System.out.println("File " + ENCRYPTED_FILE + " sent successfully");
            
            //Send MAC 

            
            	localPublicFile = new File(GENERATED_MAC);
	    	fileSize = localPublicFile.length();
            
            	fileInputStream = new FileInputStream(localPublicFile);
            	buffer = new byte[4096];
            	read = 0;
            	totalRead = 0;
            	remaining = (int) fileSize;
            
            	dataOutputStream.writeUTF(GENERATED_MAC);
            	dataOutputStream.writeLong(fileSize);
            	while ((read = fileInputStream.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
                	totalRead += read;
                	remaining -= read;
                	outputStream.write(buffer, 0, read);
            	}
            
	    }
	    else
	    {
	    	System.out.println("File not verified!!!");
	    }
	    
	    
	    
	    //Cleanup
	    System.out.println("System Cleanup");
	    File tempFile = new File(ENCRYPTED_FILE);
	    tempFile.delete();
	    tempFile = new File(GENERATED_MAC);
	    tempFile.delete();
	    tempFile = new File(DECRYPTED_FILE);
	    tempFile.delete();
	    tempFile = new File(PUBLIC_RSA);
	    tempFile.delete();
	    tempFile = new File(PRIVATE_RSA);
	    tempFile.delete();
	    tempFile = new File(AES_KEY_FILE);
	    tempFile.delete();
	    tempFile = new File(CLIENT_MAC);
	    tempFile.delete();
	    
	    
	    
            fileOutputStream.close();
            dataInputStream.close();
            inputStream.close();
            dataOutputStream.close();
            clientSocket.close();
            serverSocket.close();
            
        } catch (IOException e) {
            if(e.getMessage() == null)
            	System.out.println("Server shutdown triggered");
            else
            	System.err.println("Error: " + e.getMessage());
        }

	}
	while(active);
	 //Cleanup
	    
}
}
