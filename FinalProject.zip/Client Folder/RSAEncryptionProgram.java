import java.io.*;
import java.security.*;
import javax.crypto.*;
import java.security.spec.*;
import java.nio.file.*;

public class RSAEncryptionProgram {
public byte[] readFileBytes(String filename) throws IOException
{
    Path path = Paths.get(filename);
    return Files.readAllBytes(path);        
}

public PublicKey readPublicKey(String filename) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException
{
    X509EncodedKeySpec publicSpec = new X509EncodedKeySpec(readFileBytes(filename));
    KeyFactory keyFactory = KeyFactory.getInstance("RSA");
    return keyFactory.generatePublic(publicSpec);       
}

public PrivateKey readPrivateKey(String filename) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException
{
    PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(readFileBytes(filename));
    KeyFactory keyFactory = KeyFactory.getInstance("RSA");
    return keyFactory.generatePrivate(keySpec);     
}

public byte[] encrypt(PublicKey key, byte[] plaintext) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException
{
    Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA1AndMGF1Padding");   
    cipher.init(Cipher.ENCRYPT_MODE, key);  
    return cipher.doFinal(plaintext);
}

public byte[] decrypt(PrivateKey key, byte[] ciphertext) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException
{
    Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA1AndMGF1Padding");   
    cipher.init(Cipher.DECRYPT_MODE, key);  
    return cipher.doFinal(ciphertext);
}

public void encryptFile(String fileName, String publicName, String outputFile)
{
	try{
		PublicKey publicKey = readPublicKey(publicName);
    		File file = new File(fileName);
    		byte[] fileContent = Files.readAllBytes(file.toPath());
        	byte[] secretFile = encrypt(publicKey, fileContent);
        	try (FileOutputStream fos = new FileOutputStream(outputFile)) {
            		fos.write(secretFile);
            		System.out.println("From RSA: Successfully written bytes to file!");
        	} catch (IOException e) {
            		System.err.println("From RSA: Error writing bytes to file: " + e.getMessage());
        	}
	}
	catch(Exception e){
		e.printStackTrace();
	}
}

public void decryptFile(String fileName) throws Exception, IOException, NoSuchAlgorithmException
{
	try{
		PrivateKey privateKey = readPrivateKey("private.der");
		File file = new File(fileName);
		byte[] recoveredFile = decrypt(privateKey, Files.readAllBytes(file.toPath()));
		//recoveredFile[2] = 109; //Test for signature verification on server side
		try (FileOutputStream fos = new FileOutputStream("decryptedFile.txt")) {
            	fos.write(recoveredFile);
            	System.out.println("From RSA: Successfully written bytes to file!");
        	} 
        	catch (IOException e) {
            		System.err.println("From RSA: Error writing bytes to file: " + e.getMessage());
        	}
		
	}
	catch(Exception e){
	}
}

public void savePublicKey(PublicKey publicKey, String fileName) throws IOException {
        byte[] publicKeyBytes = publicKey.getEncoded();
        Files.write(Paths.get(fileName), publicKeyBytes);
    }
    
public void savePrivateKey(PrivateKey privateKey, String fileName) throws IOException {
        byte[] privateKeyBytes = privateKey.getEncoded();
        Files.write(Paths.get(fileName), privateKeyBytes);
    }
    
public void generateKeys()
{
	try{
	KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
	keyPairGenerator.initialize(2048); // Key size of 2048 bits
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
            
        // Get the public and private key
        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();
            
        // Save keys to files
        savePublicKey(publicKey, "public.der");
        savePrivateKey(privateKey, "private.der");
	
	}catch (NoSuchAlgorithmException | IOException e) {
            e.printStackTrace();
        }
}

public void Hello(String publicName, String privateName)
{
    try
    {
    	generateKeys();

        PublicKey publicKey = readPublicKey(publicName);
        PrivateKey privateKey = readPrivateKey(privateName);
        Signature signature = Signature.getInstance("SHA256withRSA");
    	signature.initSign(privateKey);	//Verify user A is user A by using user A's private key to verify
        File file = new File("document.txt");
        byte[] fileContent = Files.readAllBytes(file.toPath());
        signature.update(fileContent);
        byte[] digitalSignature = signature.sign();
        byte[] secretFile = encrypt(publicKey, fileContent);
        byte[] recoveredFile = decrypt(privateKey, secretFile);
        try (FileOutputStream fos = new FileOutputStream("encryptedFile.txt")) {
            fos.write(secretFile);
            System.out.println("Successfully written bytes to file!");
        } catch (IOException e) {
            System.err.println("Error writing bytes to file: " + e.getMessage());
        }
        try (FileOutputStream fos = new FileOutputStream("decryptedFile.txt")) {
            fos.write(recoveredFile);
            System.out.println("Successfully written bytes to file!");
        } catch (IOException e) {
            System.err.println("Error writing bytes to file: " + e.getMessage());
        }
        System.out.println(recoveredFile[2]);
        recoveredFile[2] = 109;
        signature.initVerify(publicKey);
        signature.update(recoveredFile);
        boolean isCorrect = signature.verify(digitalSignature);
        System.out.println(isCorrect);
    }
    catch (Exception e)
    {
        e.printStackTrace();
    }
}

}
