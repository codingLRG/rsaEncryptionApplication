import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import javax.crypto.Mac;
import java.nio.file.*;
import java.util.Arrays;

public class AESEncryptionExample {

    public static SecretKey generateAESKey() throws NoSuchAlgorithmException {
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(256);
        return keyGenerator.generateKey();
    }

    public static void saveSecretKey(SecretKey secretKey, String filename) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(filename);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
        objectOutputStream.writeObject(secretKey);
        objectOutputStream.close();
        fileOutputStream.close();
        System.out.println("Secret key saved to " + filename);
    }

    public static SecretKey loadSecretKey(String filename) throws IOException, ClassNotFoundException {
        FileInputStream fileInputStream = new FileInputStream(filename);
        ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
        SecretKey secretKey = (SecretKey) objectInputStream.readObject();
        objectInputStream.close();
        fileInputStream.close();
        return secretKey;
    }

    public static void encryptFile(String inputFile, String outputFile, SecretKey secretKey) throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        FileInputStream inputStream = new FileInputStream(inputFile);
        FileOutputStream outputStream = new FileOutputStream(outputFile);

        byte[] inputBytes = new byte[1024];
        int bytesRead;
        while ((bytesRead = inputStream.read(inputBytes)) != -1) {
            byte[] outputBytes = cipher.update(inputBytes, 0, bytesRead);
            if (outputBytes != null) {
                outputStream.write(outputBytes);
            }
        }

	
        byte[] outputBytes = cipher.doFinal();
        if (outputBytes != null) {
            outputStream.write(outputBytes);
        }

        inputStream.close();
        outputStream.close();
        System.out.println("File encrypted and saved to " + outputFile);
    }

    public static void decryptFile(String inputFile, String outputFile, SecretKey secretKey) throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, secretKey);

        FileInputStream inputStream = new FileInputStream(inputFile);
        FileOutputStream outputStream = new FileOutputStream(outputFile);

        byte[] inputBytes = new byte[1024];
        int bytesRead;
        while ((bytesRead = inputStream.read(inputBytes)) != -1) {
            byte[] outputBytes = cipher.update(inputBytes, 0, bytesRead);
            if (outputBytes != null) {
                outputStream.write(outputBytes);
            }
        }

        byte[] outputBytes = cipher.doFinal();
        if (outputBytes != null) {
            outputStream.write(outputBytes);
        }

        inputStream.close();
        outputStream.close();
        System.out.println("File decrypted and saved to " + outputFile);
    }
    
    public static void generateMAC(SecretKey secretKey, String inputFile, String outputFile) throws Exception
    {
    	Mac mac = Mac.getInstance("HmacSHA256");
    	mac.init(secretKey);
        ByteArrayOutputStream macBAOS = new ByteArrayOutputStream();
        FileOutputStream macOutputStream = new FileOutputStream(outputFile);
        FileInputStream fis = new FileInputStream(inputFile);
	byte[] buffer = new byte[1024];
        int bytesRead;

        while ((bytesRead = fis.read(buffer)) != -1) {
        	macBAOS.write(buffer, 0, bytesRead);
        }

        
	byte[] macSign = mac.doFinal(macBAOS.toByteArray());
	if (macSign != null){
		macOutputStream.write(macSign);
	}
    
    }
    
    public static boolean verifyMAC(String incomingMac, String generatedMac) throws Exception
    {
    	ByteArrayOutputStream macBAOS = new ByteArrayOutputStream();
        FileInputStream fis = new FileInputStream(incomingMac);
        ByteArrayOutputStream macBAOS2 = new ByteArrayOutputStream();
        FileInputStream fis2 = new FileInputStream(generatedMac);
	byte[] buffer = new byte[1024];
        int bytesRead;

        while ((bytesRead = fis.read(buffer)) != -1) {
        	macBAOS.write(buffer, 0, bytesRead);
        }

        buffer = new byte[1024];
        while ((bytesRead = fis2.read(buffer)) != -1) {
        	macBAOS2.write(buffer, 0, bytesRead);
        }
	

    	return Arrays.equals(macBAOS.toByteArray(),macBAOS2.toByteArray());
    }
}

